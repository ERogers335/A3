import java.util.*;
/**
 * This is a class that allows you to roll a dice at an attempt
 * to get a target number. The target numbers are 5 & 30.
 *
 * @author Evan R.
 * @version 1.2
 */

public class Roll
{
    // Random generator, and input scanner
    private Random random;
    private Scanner scanner;

    /**
     * Constructor for objects of class Roll. Creates a scanner object to
     * get user input and a random object that we will use for a random generator.
     */
    public Roll()
    {
        scanner = new Scanner(System.in);
        random = new Random();
    }

    /**
     * This is the dice rolling method. It simulates a dice roll with your
     * choice of die type and number of dice.
     * 
     * It will check each time the dice is rolled if you get a 5 or a 30 and
     * if you do it will print a winning message. If you lose it will print the 
     * results.
     *
     */
    public void DiceRoll()
    {   
        System.out.print("Enter the die type (4, 6, 8, 10, 12, 20, 100): ");
        int dieType = scanner.nextInt();
        
        System.out.print("Enter the number of dice (1-10): ");
        int numDice = scanner.nextInt();
        
        
        int min = 5;
        int max = 30;
        int ones = 0;
        int total = 0;
        List<Integer> results = new ArrayList<>();
        boolean success = false;
        
        for (int i = 0; i < numDice; i++) {
            int roll = random.nextInt(dieType) + 1;

            if (roll == 1) {
                ones++;
            }

            if (roll == min || roll == max) {
                System.out.println("You win! You rolled a " + roll);
                success = true;
            }else if (roll == dieType) {
                int openEnded = roll;
                do {
                    roll = random.nextInt(dieType) + 1;
                    openEnded += roll;
                } while (roll == dieType);
                results.add(openEnded);
                total += openEnded;
                
            } else if (roll == min || roll == max) {
                System.out.println("You win! You rolled a " + roll);
                success = true;
            
            } else{
                results.add(roll);
                total += roll;
            }
        }

        if (success) {
            System.out.println("Thank you for playing!");
        } else {
            System.out.println("Sorry, you did not win.");
            printResults(ones, results, total, success, numDice);
        }
    }

    /**
     * This is a method that gets called once the dice rolling is complete.
     * 
     * It will print the results if you did NOT win.
     * 
     *  @param ones for number of times you rolled a 1. 
     *  
     *  @param results for the results of each dice roll.
     *  
     *  @param total for the total of all the dice rolls combined.
     * 
     */

    public void printResults(int ones, List results, int total, boolean success, int numDice)
    {
        if (ones > numDice / 2) {
            System.out.println("Bust: more than 50% of the dice were ones");
        } else if (!success) {
            System.out.println("Results: " + results);
            System.out.println("Total: " + total);
        }
    }
}