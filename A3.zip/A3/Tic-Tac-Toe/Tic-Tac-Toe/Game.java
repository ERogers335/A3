import java.util.*;
/**
 * This is a classic Tic-Tac-Toe game! It allows for two players, and lets you
 * take turns until there is a winner. 
 *
 * @author Evan R.
 * @version 1.03
 */

public class Game
{
    // Creating an enum to use for the values for the board.
    enum CellValue{
        X, O, EMPTY
    }
    
    // Fields
    private Scanner in;
    private String p1;
    private String p2;
    private CellValue[][] board;

    /**
     * Constructor for objects of class Game
     * 
     * Sets players names, creates the game board, fills it with empty's
     * and then starts the game by calling the makeMove method.
     * 
     */
    public Game()
    { 
        in = new Scanner(System.in);

        //get the player's names
        System.out.print("Player 1, what's your name? ");
        p1 = in.nextLine();
        System.out.print("Player 2, what's your name? ");
        p2 = in.nextLine();

        board = new CellValue[3][3];

        //make the board EMPTY
        for(int i = 0; i < board.length; i++) {
            for(int j = 0; j < board[i].length; j++) {
                board[i][j] = CellValue.EMPTY;
            }
        }

        makeMove(board);

    }
    
    /** 
     * Gets Player 1.
     */
    public String getP1()
    {
        return p1;    
    }
    
    /**
     * Gets Player 2.
     */
    public String getP2()
    {
        return p2;
    }
    
    /**
     * Change Player 1's name.
     */
    public void setP1(String p1)
    {
        this.p1 = p1;
    }
    
    /**
     * Change Player 2's name. 
     */
    public void setP2(String p2)
    {
        this.p2 = p2;
    }

    /**
     * 
     * Draws the board at the start of the game. 
     * 
     * @param board The game board.
     */
    public void drawBoard(CellValue[][] board)
    {
        for(int i = 0; i < board.length; i++) {
            for(int j = 0; j < board.length; j++) {
                System.out.print(board[i][j]);
            }
            System.out.println();
        }
    }
    
    /**
     * 
     * This is the heart of the game. It starts the first move of the game and
     * then uses a while loop to keep the game going until there is a winner
     * or there is a tie.
     * 
     * @param board The game board.
     */
    public void makeMove(CellValue[][] board) 
    {
        int row = 0;
        int col = 0;

        //Keep track of whose turn it is
        boolean isPlayer1 = true;
       
        boolean gameEnded = false;

        while(!gameEnded) {
            drawBoard(board);

            if(isPlayer1) {
                System.out.println(p1 + "'s Turn (X):");
            } else {
                System.out.println(p2 + "'s Turn (O):");
            }
            
            //play game
            while(true) {
                int min = 0;
                int max = 2;
                
                System.out.println("Enter a row (0, 1, or 2): ");
                row = in.nextInt();
                System.out.println("Enter a column (0, 1, or 2): ");
                col = in.nextInt();

                //Check if row and column are valid
                if(row < min || col < min || row > max || col > max) {
                    System.out.println("Your row and column are out of bounds!");
                } else if(board[row][col] != CellValue.EMPTY) {
                    System.out.println("Someone has already made a move there!");
                } else {
                    break;
                }
            }
            
            if(isPlayer1){
                board[row][col] = CellValue.X;
            } else {
                board[row][col] = CellValue.O;
            }

            //check if a player has won
            if(hasWon(board) == CellValue.X) {
                System.out.println(p1 + " has won!");
                gameEnded = true;
                drawBoard(board);
            } else if(hasWon(board) == CellValue.O) {
                System.out.println(p2 + " has won!");
                gameEnded = true;
                drawBoard(board);
            } else {
                if(hasTied(board)) {
                    System.out.println("Its a tie!");
                    gameEnded = true;
                } else {
                    //Continue game and toggle turn
                    isPlayer1 = !isPlayer1;
                }
            }
        }
    }

    /**
     * 
     * This is the method for checking rows, columns, and diaganols for a win
     * on each turn of the game.
     * 
     * @param board The game board.
     * 
     */
    public CellValue hasWon(CellValue[][] board) 
    {
        //Check for row
        for(int i = 0; i < board.length; i++) {
            if(board[i][0] == board[i][1] && board[i][1] == board[i][2] && 
            board[i][0] != CellValue.EMPTY) {
                return board[i][0];
            }
        }
        //Check for column
        for(int j = 0; j < board.length; j++) {
            if(board[0][j] == board[1][j] && board[1][j] == board[2][j] &&
            board[0][j] != CellValue.EMPTY) {
                return board[0][j];
            }
        }
        //Check for diagonals both ways
        if(board[0][0] == board[1][1] && board[1][1] == board[2][2] &&
        board[0][0] != CellValue.EMPTY) {
            return board[0][0];
        }
        if(board[2][0] == board[1][1] && board[1][1] == board[0][2] &&
        board[2][0] != CellValue.EMPTY) {
            return board[2][0];
        }

        //Nobody has won
        return CellValue.EMPTY;
    }

    /**
     * 
     * Checks for a tie by checking to see if any value in the board array
     * is equal to empty, which would mean that there are still open spaces
     * on the board.
     * 
     * @param board The game board.
     * 
     */
    public boolean hasTied(CellValue[][] board) 
    {
        for(int i = 0; i < board.length; i++){
            for(int j = 0; j < board.length; j++){
                if(board[i][j] == CellValue.EMPTY){
                    return false;
                }
            }
        }
        return true;
    }
}